from typing import Union
import control
from game_master.gameSurface import HaveNameSurface


class Item:
    def __init__(self, bgp: Union[list[HaveNameSurface], HaveNameSurface] = None):
        self.__bgp = []
        for s in bgp:
            self.__bgp.append(s.convert_alpha())
        self.button_list = [1]
        self.surface_button_list = [1]
        self.box_list = [1]
        self.surface_box_list = [1]
        self.button = control.button.Button()
        self.surfaceButton = control.button.SurfaceButton()
        self.textBox = control.textBox.TextBox()
        self.surfaceTextBox = control.textBox.SurfaceTextBox()
