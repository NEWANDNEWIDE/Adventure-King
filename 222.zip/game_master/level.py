import game_master.gameSurface


class Level:
    def __init__(self, screen):
        self.screen = screen

    def render_map(self):
        pass

    def render_object(self):
        pass

    def render_ui(self):
        pass

    def render_bag(self):
        pass

    def render_other(self):
        pass
    