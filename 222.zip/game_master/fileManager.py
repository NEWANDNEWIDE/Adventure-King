import os
import pygame.image
import settings
from game_master import gameSurface


def loading_item() -> list[gameSurface.HaveNameSurface]:
    path_surface = os.path.join(settings.ITEMPATH, "surface")
    item_surface = []
    for name in os.listdir(path_surface):
        s = gameSurface.HaveNameSurface(surface=pygame.image.load(os.path.join(path_surface, name))).convert_alpha()
        s.name = name
        item_surface.append(s)
    return item_surface


def loading_game_surfaces():
    pass