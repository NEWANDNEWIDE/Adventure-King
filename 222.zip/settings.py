WIDTH, HEIGHT = 800, 600
FPS = 1000
TITLE = "冒险王"
TITLE_JP = "アドベンチャーキング"
ITEMPATH = "../res/item"
GAMEPATH = "../res/game"
MUSICPATH = "../res/music"