import pygame
from control.button import Button

pygame.init()


def f(func=None, *args):
    if func:
        func(*args)

def function(a, b):
    print(a + b)

def c():
    print(666)

f(function, 1, 1)
f(c)